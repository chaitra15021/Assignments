﻿using System;
 
class Matrix
{
    private int[,] data = new int[3,3];
 
    public int this[int row, int col]
    {
        get
        {
            return data[row, col];
        }
        set
        {
            data[row, col] = value;
        }
    }
}
 
class Program
{
    static void Main()
    {
        Matrix m = new Matrix();
 
        m[0,0] = 10;
        m[0,1] = 20;
        m[1,0] = 30;
        m[1,1] = 40;
 
       
        Console.WriteLine(m[0,0]);
        Console.WriteLine(m[0,1]);
        Console.WriteLine(m[1,0]);
        Console.WriteLine(m[1,1]);
    }
}
