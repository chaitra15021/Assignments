﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
     
        var urls = Enumerable.Range(1, 20)
            .Select(i => $"https://jsonplaceholder.typicode.com/posts/{i}")
            .ToList();

        try
        {
            await DownloadAllAsync(urls);
            Console.WriteLine("All downloads completed successfully.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Some downloads failed!");
            Console.WriteLine(ex.Message);
        }
    }

    public static async Task DownloadAllAsync(List<string> urls)
    {
        var semaphore = new SemaphoreSlim(5); 
        var tasks = new List<Task>();

        foreach (var url in urls)
        {
            tasks.Add(ProcessUrlAsync(url, semaphore));
        }

        try
        {
            await Task.WhenAll(tasks);
        }
        catch
        {
        
            var exceptions = tasks
                .Where(t => t.IsFaulted)
                .SelectMany(t => t.Exception.InnerExceptions)
                .ToList();

            Console.WriteLine($"Total failures: {exceptions.Count}");

            foreach (var ex in exceptions)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            throw; 
        }
    }

    private static async Task ProcessUrlAsync(string url, SemaphoreSlim semaphore)
    {
        await semaphore.WaitAsync(); 

        try
        {
            await DownloadAsync(url);
        }
        finally
        {
            semaphore.Release(); 
        }
    }

    private static async Task DownloadAsync(string url)
    {
        using var client = new HttpClient();

        try
        {
            var data = await client.GetStringAsync(url);

            Console.WriteLine($"Downloaded: {url}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed: {url}");
            throw new Exception($"Error downloading {url}: {ex.Message}");
        }
    }
}