﻿using System;

public class TimeStamp
{
    private int hours;
    private int minutes;
    private int seconds;

    
    public int Hours
    {
        get { return hours; }
        set
        {
            hours = value < 0 ? 0 : value;
            Normalize();
        }
    }

    public int Minutes
    {
        get { return minutes; }
        set
        {
            minutes = value < 0 ? 0 : value;
            Normalize();
        }
    }

    public int Seconds
    {
        get { return seconds; }
        set
        {
            seconds = value < 0 ? 0 : value;
            Normalize();
        }
    }

    
    public TimeStamp()
    {
        hours = 0;
        minutes = 0;
        seconds = 0;
    }

    
    public TimeStamp(int h, int m, int s)
    {
        hours = h < 0 ? 0 : h;
        minutes = m < 0 ? 0 : m;
        seconds = s < 0 ? 0 : s;

        Normalize();
    }

  
    private void Normalize()
    {
        // seconds → minutes
        minutes += seconds / 60;
        seconds = seconds % 60;

        // minutes → hours
        hours += minutes / 60;
        minutes = minutes % 60;

        // 24-hour format
        hours = hours % 24;
    }

   
    public void AddSeconds(int s)
    {
        if (s < 0) return;

        seconds += s;
        Normalize();
    }

    public void AddMinutes(int m)
    {
        if (m < 0) return;

        minutes += m;
        Normalize();
    }

    public void AddHours(int h)
    {
        if (h < 0) return;

        hours += h;
        Normalize();
    }

 
    public override string ToString()
    {
        return $"{hours}h {minutes}m {seconds}s";
    }
}


class Program
{
    static void Main()
    {
        Console.WriteLine("Welcome to Back to the Future.\n");
        Console.WriteLine("Here we are demonstrating a TimeStamp class.\n");

      
        TimeStamp t1 = new TimeStamp();
        Console.WriteLine("Default construction: " + t1);

      
        TimeStamp t2 = new TimeStamp(13, 12, 11);
        Console.WriteLine("With timing info: " + t2);

        Console.WriteLine();

       
        t1.AddHours(12);
        t2.AddHours(1);
        Console.WriteLine("Let's set the hours 12h ahead: " + t1 + " or for the second " + t2);

     
        t1.AddMinutes(66);
        t2.AddMinutes(66);
        Console.WriteLine("Let's set the minutes 66m ahead: " + t1 + " or for the second " + t2);

        
        t1.AddSeconds(138);
        t2.AddSeconds(138);
        Console.WriteLine("Let's set the seconds 138s ahead: " + t1 + " or for the second " + t2);
    }
}