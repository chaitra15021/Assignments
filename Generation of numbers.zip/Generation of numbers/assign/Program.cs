﻿using System;

public interface IGenerator
{
    int Next();     // give next number
    void Reset();   // restart sequence
}

//  Natural Numbers:
public class NaturalGenerator : IGenerator
{
    private int current = -1;

    public int Next()
    {
        current++;
        return current;
    }

    public void Reset()
    {
        current = -1;
    }
}

// Powers of Two: 1,2,4,8...
public class PowersOfTwoGenerator : IGenerator
{
    private int current = 1;
    private bool first = true;

    public int Next()
    {
        if (first)
        {
            first = false;
            return 1;
        }

        current *= 2;
        return current;
    }

    public void Reset()
    {
        current = 1;
        first = true;
    }
}

//  Fibonacci: 1,1,2,3,5...
public class FibonacciGenerator : IGenerator
{
    private int prev = 0;
    private int current = 1;

    public int Next()
    {
        int next = prev + current;
        prev = current;
        current = next;
        return prev;
    }

    public void Reset()
    {
        prev = 0;
        current = 1;
    }
}

//  Random Numbers
public class RandomGenerator : IGenerator
{
    private Random rand = new Random();

    public int Next()
    {
        return rand.Next();
    }

    public void Reset()
    {
        rand = new Random(); // reset generator
    }
}

//  MAIN PROGRAM
class Program
{
    static void PrintSeries(IGenerator generator, int count)
    {
        for (int i = 0; i < count; i++)
        {
            Console.Write(generator.Next() + " ");
        }
        Console.WriteLine();
    }

    static void Main()
    {
        Console.WriteLine("Welcome to Generator of Numbers.\n");

        Console.WriteLine("Series of natural numbers:");
        PrintSeries(new NaturalGenerator(), 20);

        Console.WriteLine("\nPowers of two:");
        PrintSeries(new PowersOfTwoGenerator(), 20);

        Console.WriteLine("\nFibonacci Sequence:");
        PrintSeries(new FibonacciGenerator(), 20);

        Console.WriteLine("\nRandom series of numbers:");
        RandomGenerator randomGen = new RandomGenerator();
        PrintSeries(randomGen, 20);

        Console.WriteLine();
        PrintSeries(randomGen, 20); 
    }
}