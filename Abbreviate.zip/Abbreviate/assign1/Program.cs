﻿using System;

public class Abbreviator
{
    public string Abbreviate(string text)
    {
     
        if (string.IsNullOrWhiteSpace(text))
        {
            return "";
        }

        string result = "";

        
        string[] words = text.Split(' ');

        
        foreach (string word in words)
        {
            if (!string.IsNullOrWhiteSpace(word))
            {
                result += char.ToUpper(word[0]);
            }
        }

        return result;
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("Welcome to Abbreviate This ...\n");

        Abbreviator ab = new Abbreviator();

        string input = "laughing out loud";
        string output = ab.Abbreviate(input);

        Console.WriteLine(output + " means " + input);
    }
}
