﻿using System;
using System.IO;
using System.Reflection;
using ProviderProtocol;

class Program
{
    static void Main()
    {
        string pluginFolder = "plugins";

        if (!Directory.Exists(pluginFolder))
            Directory.CreateDirectory(pluginFolder);

        string[] dllFiles = Directory.GetFiles(pluginFolder, "*.dll");

        foreach (var file in dllFiles)
        {
            Assembly assembly = Assembly.LoadFrom(file);

            foreach (Type type in assembly.GetTypes())
            {
                if (typeof(IProvider).IsAssignableFrom(type) && !type.IsInterface)
                {
                    IProvider provider =
                        (IProvider)Activator.CreateInstance(type);

                    Console.WriteLine($"Loaded: {provider.Name}");

                    provider.Execute();
                }
            }
        }
    }
}
