﻿namespace ProviderProtocol
{
    public interface IProvider
    {
        string Name { get; set; }
        void Execute();
    }
}