﻿using System;
using ProviderProtocol;

namespace BankProvider
{
    public class BankOfBakuProvider : IProvider
    {
        public string Name { get; set; } = "Bank Of Baku";

        public void Execute()
        {
            Console.WriteLine("Bank Of Baku plugin executed!");
        }
    }
}