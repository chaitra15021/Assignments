﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncSingletonDemo
{
    
    public class Configuration
    {
        public string Data { get; set; }
    }

  
    public class ConfigurationService
    {
        private static Configuration _config;
        private static readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1, 1);

        public static async Task<Configuration> GetConfigurationAsync()
        {
           
            if (_config != null)
                return _config;

            await _semaphore.WaitAsync(); 

            try
            {
               
                if (_config == null)
                {
                    _config = await LoadFromDatabaseAsync();
                }
            }
            finally
            {
                _semaphore.Release(); 
            }

            return _config;
        }

        private static async Task<Configuration> LoadFromDatabaseAsync()
        {
            
            Console.WriteLine("Loading configuration from database...");
            await Task.Delay(3000);

            return new Configuration
            {
                Data = "Config Loaded Once"
            };
        }
    }

    // 🔹 Program (Test with multiple threads)
    class Program
    {
        static async Task Main(string[] args)
        {
            var tasks = new List<Task>();

            // Simulate multiple concurrent calls
            for (int i = 0; i < 10; i++)
            {
                tasks.Add(Task.Run(async () =>
                {
                    var config = await ConfigurationService.GetConfigurationAsync();
                    Console.WriteLine($"Thread {Task.CurrentId}: {config.Data}");
                }));
            }

            await Task.WhenAll(tasks);

            Console.WriteLine("All threads completed.");
        }
    }
}